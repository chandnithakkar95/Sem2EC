package pjava.ch04.subclass.bank;

import pjava.ch04.exceptions.bank.BankAccount;

public class SavingsAccount extends BankAccount {

   public SavingsAccount(double rate) {
        super(0);
        interestRate = rate;
   }

   public SavingsAccount(double initial_balance, double rate)  {  
        super(initial_balance);
        //deposit(5);
        interestRate = rate;
   }

   public void addInterest() {  
        double interest = getBalance() * interestRate / 100;
        //super.x = 5;
        //this.x = 10;
        //super.deposit(interest);
        //this.deposit(interest);
   }

    public static void abc() {
        //super and this is not available in sub-class method implementations
    }

    @Override
    public String toString() {
        return "Saving Account:\n   Balance: " + getBalance() + "\n   Interest Rate " + interestRate;
    }

    private double interestRate;

}
