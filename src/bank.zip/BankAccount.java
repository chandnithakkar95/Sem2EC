package pjava.ch04.exceptions.bank;

public class BankAccount{
   public BankAccount()   {
       accno = next_accno++;
       balance = 0;
   }

    public long getAccno() {
        return accno;
    }
   
   public BankAccount(double initialBalance)   {
       accno = next_accno++;
       balance = initialBalance;
   }
   public void deposit(double amount)   {
       double newBalance = balance + amount;
       balance = newBalance;
   }
   public void withdraw(double amount)
           throws DailyLimitException, InsuffBalanceException {
       double newBalance = balance - amount;
       if ( amount > 25000 )
           throw ( new DailyLimitException() );
       else if ( amount > balance )
           throw ( new InsuffBalanceException() );
       balance = newBalance;
   }
   public double getBalance()
   {
       return balance;
   }

   private final long accno;
   private double balance;
   private static long next_accno=10000;
   
}

class InsuffBalanceException extends Exception {}

class DailyLimitException extends Exception {}