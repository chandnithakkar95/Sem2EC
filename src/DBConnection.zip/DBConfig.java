package pjava.ch10.jdbc;

public interface DBConfig {

    String DB_DRIVER = "org.postgresql.Driver";
    String DB_URL = "jdbc:postgresql://10.100.71.21/test";
    String DB_USER = "test";
    String DB_PWD = "test";

}
